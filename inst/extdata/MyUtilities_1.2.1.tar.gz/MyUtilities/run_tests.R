########################################################################################################################
setwd("O:/TRANSP/IsenbergLars/Projekte/MyUtilities")
library("tidyverse")
library("data.table")
rm(list = ls(all.names = TRUE))

function_sources <- dir("R", full.names = TRUE)
for (script in function_sources) {
    source(script)
}

########################################################################################################################
full_test_suite <- RUnit::defineTestSuite("Full test suite", dirs = "RUnitTests")
RUnit::isValidTestSuite(full_test_suite)
runit <- RUnit::runTestSuite(full_test_suite)
RUnit::printTextProtocol(runit)


