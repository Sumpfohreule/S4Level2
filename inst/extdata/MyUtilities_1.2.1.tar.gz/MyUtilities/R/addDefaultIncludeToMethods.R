addDefaultIncludeToMethods <- function(packet_r_folder) {
    file_vector <- dir(packet_r_folder, pattern = "\\.R", full.names = TRUE)

    file_table <- data.table(path = file_vector) %>%
        mutate(type = map(path, findScriptType) %>%
                   unlist())



}

findScriptType <- function(packet_r_folder) {
    full_script <- readLines(packet_r_folder)

    for (line in full_script) {
        if (stringr::str_detect(line, pattern = "[ ]*function\\(")) {
            return("function")
        }
        if (stringr::str_detect(line, pattern = "[ ]*setClass\\(")) {
            return("class")
        }
        if (stringr::str_detect(line, pattern = "[ ]*setGeneric\\(")) {
            return("generic")
        }
    }

    return(as.character(NA))
}

findRelatedGeneric <- function(method_name, packet_r_folder) {

}


