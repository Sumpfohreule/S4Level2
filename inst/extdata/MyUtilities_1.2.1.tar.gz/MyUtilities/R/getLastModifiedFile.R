########################################################################################################################
#' Returns path for the most recent modfied file
#' 
#' Within a given folder path the path to the file with the most recent changes is returned
#' 
#' @param folder Path to the folder, containing the files to select from
#' @param pattern A regex pattern to select files by
#' @param recursive Flag to determine if folders should be included recursively
#' @return Returns path of a single file which was modified most recently. Error is thrown if none was found!
#' @export 
#' 
getLastModifiedFile <- function(folder, pattern = NULL, recursive = FALSE) {
    all.files <- data.table(path = dir(folder, full.names = TRUE, pattern = pattern, recursive = recursive))
    all.files[, ":=" (
            is.file = !dir.exists(path),
            is.not.lock.file = !str_detect(basename(path), pattern = "^~\\$"),
            last.modified = file.mtime(path))]
    all.files <- all.files[is.file == TRUE & is.not.lock.file]
    if (nrow(all.files) == 0) {
        stop("No files have been found with the given pattern '", pattern, "' within folder\n", folder)
    } else {
        latest.file <- all.files[max(last.modified) == last.modified, path]
        return(latest.file)
    }
}
