test_that("Converts to seconds", {
    expect_equal(convertToPeriod(33), lubridate::as.period("33S"))
})

test_that("Converts to minutes", {
    expect_equal(convertToPeriod(60 * 33), lubridate::as.period("33M"))
})

test_that("Converts to hours", {
    expect_equal(convertToPeriod(60 * 60 * 12), lubridate::as.period("12H"))
})

test_that("Converts to days", {
    expect_equal(convertToPeriod(24 * 60 * 60 * 12), lubridate::as.period("12d"))
})

test_that("Error on converting to minutes with fraction", {
    expect_error(convertToPeriod(60 * 33 + 10))
})

test_that("Error on converting to hours with fraction", {
    expect_error(convertToPeriod(60 * 60 * 12 + 10))
})

test_that("Error on converting to days with fraction", {
    expect_error(convertToPeriod(24 * 60 * 60 * 12 + 10))
})