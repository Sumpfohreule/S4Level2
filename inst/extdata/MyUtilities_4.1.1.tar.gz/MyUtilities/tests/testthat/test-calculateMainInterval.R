test_that("Interval from 2 values", {
    expect_equal(calculateMainInterval(c(10, 40)), 30)
})

test_that("Interval from multiple even spaced values", {
    expect_equal(calculateMainInterval(seq(0, 3000, 30)), 30)
})

test_that("Interval from negative values", {
    expect_equal(calculateMainInterval(seq(-3000, 0, 30)), 30)
})

test_that("Day interval from posix dates", {
    date_limits <- as.POSIXct(c("2000-01-01", "2000-02-01"), tz = "UTC")
    date_sequence <- seq(date_limits[1], date_limits[2], 3600 * 24)
    expect_equal(calculateMainInterval(date_sequence), 3600 * 24)
})

test_that("Negative interval from reversed sequence", {
    expect_equal(calculateMainInterval(seq(3000, 0, -30)), -30)
})

test_that("Negative day interval from posix dates", {
    date_limits <- as.POSIXct(c("2000-02-01", "2000-01-01"), tz = "UTC")
    date_sequence <- seq(date_limits[1], date_limits[2], -3600 * 24)
    expect_equal(calculateMainInterval(date_sequence), -3600 * 24)
})

test_that("Find the more prevalent interval", {
    expect_equal(calculateMainInterval(c(seq(1, 10, 2), 100, 150, 200)), 2)
})

test_that("Error on having 2 intervals of same frequency", {
    expect_error(calculateMainInterval(c(1, 5, 9, 100, 150, 200)))
})

test_that("Error on having only one value", {
    expect_error(calculateMainInterval(100))
})
