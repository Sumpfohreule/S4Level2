########################################################################################################################
#' Find the most prevalent interval in a vector
#'
#' The interval between all neighboring vector values is calculated and the most frequent one returned.
#' Can be used to find the actual logging interval between dates if there are gaps in the vector.
#' An error is thrown if more than one interval with the same frequency exists.
#'
#' @param vector A vector of values which must be convertible to numeric (dates, date-times, etc.)
#' @export
#'
calculateMainInterval <- function(vector) {
    assertthat::assert_that(length(vector) > 1)
    vector <- as.numericTryCatch(vector)
    diff.counts <- table(diff(as.numeric(vector)))
    diff.value <- attr(diff.counts[diff.counts == max(diff.counts)], "names")
    if (length(diff.value) > 1) {
        stop("At least two intervals with the same frequency were found. Consider splitting the data")
    }
    return(as.numeric(diff.value))
}
