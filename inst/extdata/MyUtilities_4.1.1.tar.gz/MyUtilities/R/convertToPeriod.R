#' Converts a numeric value in seconds to the highest period (up to days) if it can fit evenly
#'
#' @export
convertToPeriod <- function(seconds) {
    days <- seconds / 86400
    if (days > 1) {
        return(lubridate::as.period(days, "days"))
    }
    hours <- seconds / 3600
    if (hours > 1) {
        return(lubridate::as.period(hours, "hours"))
    }
    minutes <- seconds / 60
    if (minutes > 1) {
        return(lubridate::as.period(minutes, "minutes"))
    }
    return(lubridate::as.period(seconds, "seconds"))
}

